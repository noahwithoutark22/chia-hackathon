import fnmatch
import logging

from pyuvm._error_classes import UVMFactoryError, UVMNotImplemented
from pyuvm._utility_classes import FactoryData, Override, Singleton, uvm_void

# pyuvm refactors the factory, taking advantage Python's
# superiority in terms of OOP features and lack of types.

# Implementing section 8 in the IEEE Specification
#
# The IEEE spec assumes that UVM is being written in SystemVerilog,
# a language that does not allow you to control how classes get defined.
# Python has more control in this area. With Python we can set things up
# so that any class that extends uvm_void automatically gets registered
# into the factory.

# Therefore there is no need for 8.2.2 the type_id, that
# is a SystemVerilog artifact as is 8.2.3
# There is also no need for 8.2.4, the uvm_object_registry.
# The FactoryMeta class causes all classes from uvm_void
# down to automatically register themselves with the factory
# by copying themselves into a dict.

# However there is a need to provide the methods in 8.


# 8.3.1.1
class uvm_factory(metaclass=Singleton):
    """
    The uvm_factory is a singleton that delivers all UVM factory functions.
    """

    # 8.3.1.2.1 get
    # There is no get() method in Python singletons.  Instead you instantiate
    # the singleton as normal and you automatically get the singleton.

    # 8.3.1.3 register
    # Not implemented
    # There is no register in pyuvm.  Instead the factory builds its class
    # database through introspection.

    def __init__(self):
        self.fd = FactoryData()
        self.logger = logging.getLogger("Factory")
        self.debug_level = 1

    def clear_all(self):
        """
        Clear all the classes and overrides from the factory
        """
        self.fd.clear_classes()
        self.clear_overrides()

    def clear_overrides(self):
        """
        Clear all the overrides from the factory
        """
        self.fd.clear_overrides()

    def __set_override(self, original, override, path=None):
        if original not in self.fd.overrides:
            self.fd.overrides[original] = Override()
        self.fd.overrides[original].add(override, path)

    # 8.3.1.3
    def set_inst_override_by_type(self, original_type, override_type, full_inst_path):
        """
        :param original_type: The original type being overridden
        :param override_type: The overriding type
        :param full_inst_path: The inst where this happens
        :return: None

        Override an instance with a new type if original type is at that path
        """

        # The intention here is to only override when a type of original_type
        # is at the full_inst_path provided. If someone stores a different
        # class at full_inst_path then the override will not happen.
        #
        #
        # We capture this by storing the original and override types as a
        # tuple at the full inst path.  Later we'll retrieve the tuple
        # and check the type of the object at the full_inst_path.
        #
        # instance_overrides is an OrderedDict, so we will check
        # the paths in the order they are registered later.

        assert issubclass(original_type, uvm_void), (
            "You tried to override a non-uvm_void class"
        )
        assert issubclass(override_type, uvm_void), (
            "You tried to use a non-uvm_void class as an override"
        )
        self.__set_override(original_type, override_type, full_inst_path)

    # 8.3.1.4.1
    def set_inst_override_by_name(
        self, original_type_name, override_type_name, full_inst_path
    ):
        """
        :param original_type_name: the name of type being replaced
        :param override_type_name: the name of the substitute type
        :param full_inst_path: The path to the instance
        :return: None

        Override a specific instance  using strings that contain
        the names of the types.
        """

        # Here we use the names of classes instead of the classes.
        # The original_name doesn't need to be the name of a class,
        # it can be an arbitrary string. The override_name must
        # be the name of a class.
        #
        # Later we will retrieve this by searching through the
        # keys for a match to a path and then checking that
        # the name given in the search matches the original_name

        assert isinstance(full_inst_path, str), "The inst_path must be a string"
        assert isinstance(original_type_name, str), "Original_name must be a string"
        assert isinstance(override_type_name, str), "Override_name must be a string"
        try:
            override_type = self.fd.classes[override_type_name]
        except KeyError:
            raise UVMFactoryError(
                f"{override_type_name}" + " has not been defined."
            ) from None

        # Set type override by name can use an arbitrary string as a key
        # instead of a type. Fortunately Python dicts don't care about
        # the type of the key.
        try:
            original_type = self.fd.classes[original_type_name]
        except KeyError:
            original_type = original_type_name

        self.__set_override(original_type, override_type, full_inst_path)

    # 8.3.1.4.2
    def set_type_override_by_type(self, original_type, override_type, replace=True):
        """
        :param original_type: The original type to be overridden
        :param override_type: The new type that will override it
        :param replace: If the override exists, only replace it if this is True
        :return: None

        Override one type with another type globally
        """
        assert issubclass(original_type, uvm_void), (
            "You tried to override a non-uvm_void class"
        )
        assert issubclass(override_type, uvm_void), (
            "You tried to use a non-uvm_void class as an override"
        )
        if (
            original_type not in self.fd.overrides
            or self.fd.overrides[original_type].type_override is None
            or replace
        ):
            self.__set_override(original_type, override_type)

    # 8.3.1.4.2
    def set_type_override_by_name(
        self, original_type_name, override_type_name, replace=True
    ):
        """
        :param original_type_name: The name of the type to be
            overridden or an arbitrary string.
        :param override_type_name: The name of the overriding type.
            It must have been declared.
        :param replace: If the override already exists only replace
            if this is True

        Override one type with another type globally using strings
        containing the type names.
        """
        assert isinstance(original_type_name, str), "Original_name must be a string"
        assert isinstance(override_type_name, str), "Override_name must be a string"
        try:
            override_type = self.fd.classes[override_type_name]
        except KeyError:
            raise UVMFactoryError(
                f"{override_type_name}" + " has not been defined."
            ) from None

        # Set type override by name can use an arbitrary string as a key
        # instead of a type

        # Fortunately Python dicts don't care about the type of the key.
        try:
            original_type = self.fd.classes[original_type_name]
        except KeyError:
            original_type = original_type_name

        if (
            original_type not in self.fd.overrides
            or self.fd.overrides[original_type].type_override is None
            or replace
        ):
            self.__set_override(original_type, override_type)

    def __find_override(self, requested_type, parent_inst_path="", name=""):
        if not isinstance(requested_type, str):
            assert issubclass(requested_type, uvm_void), (
                f"You must create uvm_void descendants not {requested_type}"
            )

        if parent_inst_path == "":
            inst_path = name
        elif name != "":
            inst_path = parent_inst_path + "." + name
        else:
            inst_path = parent_inst_path

        new_cls = self.fd.find_override(requested_type, inst_path)
        if isinstance(new_cls, str):
            self.logger.error(
                '"%s" is not declared and is not an override string', new_cls
            )
            return None
        else:
            return new_cls

    def create_object_by_type(self, requested_type, parent_inst_path="", name=""):
        """
        :param requested_type: The type that we request but that can be
            overridden
        :param parent_inst_path: The get_full_name path of the parent
        :param name: The name of the instance requested_type("name")
        :raises: UVMFactoryError if the type is not in the factory
        :return: Type that is child of uvm_object.

        8.3.1.5 Creation
        If the type is is not in the factory we raise UVMFactoryError
        """
        new_type = self.__find_override(requested_type, parent_inst_path, name)
        if new_type is None:
            raise UVMFactoryError(f"{requested_type} not in uvm_factory()")
        return new_type(name)

    # 8.3.1.5
    def create_object_by_name(self, requested_type_name, parent_inst_path="", name=""):
        """
        :param requested_type_name: the type that could be overridden
        :param parent_inst_path: A path if we are checking for inst overrides
        :param name: The name of the new object.
        :raises: UVMFactoryError if the type is not in the factory
        :return: A uvm_object with the name given

        Create an object using a string to define its uvm_object type.
        """
        if name is None or name == "":
            raise UVMFactoryError(
                "Parameter name must be specified in create_object_by_name"
            )

        # Find the requested_type_name in registered classes or overrides if
        # the string has been registered with an override.
        try:
            requested_type = FactoryData().classes[requested_type_name]
        except KeyError:
            if requested_type_name in self.fd.overrides:
                requested_type = requested_type_name
            else:
                raise UVMFactoryError(
                    f"Requested type {requested_type_name} not in "
                    "uvm_factory()  or overrides"
                ) from None

        new_obj = self.create_object_by_type(requested_type, parent_inst_path, name)
        return new_obj

    # 8.3.1.5
    def create_component_by_type(
        self, requested_type, parent_inst_path="", name="", parent=None
    ):
        """
        :param requested_type: Type type to be overridden
        :param parent_inst_path: The inst path if we are looking
            for inst overrides
        :param name: Concatenated with parent_inst_path if it
            exists for inst overrides
        :param parent: The parent component
        :raises: UVMFactoryError if the type is not in the factory
        :return: a uvm_component with the name an parent given.

        Create a component of the requested uvm_component type.
        If the type is is not in the factory we raise UVMFactoryError
        """

        if name is None:
            raise UVMFactoryError("Parameter name must be specified in function call.")

        new_type = self.__find_override(requested_type, parent_inst_path, name)

        if new_type is None:
            raise UVMFactoryError(f"{requested_type} not in uvm_factory()")

        new_comp = new_type(name, parent)
        return new_comp

    # 8.3.1.5
    def create_component_by_name(
        self, requested_type_name, parent_inst_path="", name="", parent=None
    ):
        """
        Create a components using the name of the requested uvm_component type

        :param requested_type_name: the type that could be overridden
        :param parent_inst_path: A path if we are checking for inst overrides
        :param name: The name of the new object.
        :param parent: The component's parent component
        :raises: UVMFactoryError if the type is not in the factory
        :return: A uvm_object with the name given
        """
        try:
            requested_type = FactoryData().classes[requested_type_name]
        except KeyError:
            if requested_type_name in self.fd.overrides:
                requested_type = requested_type_name
            else:
                raise UVMFactoryError(
                    f"Requested type {requested_type_name} not in "
                    "uvm_factory()  or overrides"
                ) from None

        new_obj = self.create_component_by_type(
            requested_type, parent_inst_path, name, parent
        )
        return new_obj

    # 8.3.1.6.1
    def set_type_alias(self, alias_type_name, original_type):
        """
        :param alias_type_name:A string that will reference the original type
        :param original_type:The original type toe be referenced
        :raises: UVMNotImplemented Not implemented as it does not seem to
        exist in the SystemVerilog UVM
        :return:None

        """
        # This method does not seem to be implemented in SystemVerilog
        # so I'm skipping it now.
        raise UVMNotImplemented("set_type_alias is not implemented in SystemVerilog")

    # 8.3.1.6.2
    def set_inst_alias(self, alias_type_name, original_type, full_inst_path):
        """
        :param alias_type_name:A string that will reference the original type
        :param original_type:The original type toe be referenced
        :param full_inst_path: The instance path where this alias is active
        :raises: UVMNotImplemented  Not implemented as it does
                 not seem to exist in SystemVerilog UVM
        :return:None

        """

        # This method does not seem to be implemented in SystemVerilog
        # so I'm skipping it now.
        raise UVMNotImplemented("set_type_inst is not implemented in SystemVerilog")

    # 8.3.1.7 Introspection

    # 8.3.1.7.1
    def find_override_by_type(self, requested_type, full_inst_path):
        """
        :param requested_type: The type whose override you want
        :param full_inst_path: The inst path where one looks
        :raises: UVMFactoryError if the type is not in the factory
        :return: class object

        Given a type and instance path, return the override class object.
        """
        override = self.__find_override(requested_type, full_inst_path)
        return override

    # 8.3.1.7.1
    def find_override_by_name(self, requested_type_name, full_inst_path):
        """
        :param requested_type_name:
        :param full_inst_path:
        :raises: UVMFactoryError if the type is not in the factory
        :return: class object

        Given a path and the name of a class return its overriding class object
        """
        assert isinstance(requested_type_name, str), (
            f"requested_type_name must be a string not a {type(requested_type_name)}"
        )
        requested_type = None  # Appeasing the linter
        try:
            requested_type = self.fd.classes[requested_type_name]
        except KeyError:
            UVMFactoryError(f"{requested_type_name} is not a defined class name")
        return self.find_override_by_type(requested_type, full_inst_path)

    # 8.3.1.7.2
    def find_wrapper_by_name(self):
        """
        :raises: UVMNotImplemented There are no wrappers in
            **pyuvm** so this is not implemented.

        """
        raise UVMNotImplemented(
            "There are no wrappers in pyuvm. So find_wrapper_by_name is not implemented"
        )

    # 8.3.1.7.3
    def is_type_name_registered(self, type_name):
        """
        :param type_name: string that is name of a type
        :return: boolean True if type is registered

        Checks that a type of this name is registered with the factory.
        """
        assert isinstance(type_name, str), (
            "is_type_name_registered() takes a"
            " string as its argument not {type(type_name)}"
        )
        return type_name in self.fd.classes

    # 8.3.1.7.4
    def is_type_registered(self, uvm_type):
        """
        :param uvm_type: The type to be checked
        :return: boolean True if type is registered

        Checks that a type is registered. The argument is named "obj" in
        the spec, but that name is ridiculous and confusing.


        """
        assert issubclass(uvm_type, uvm_void), (
            "is_type_registered() takes a subclass of uvm_void "
            "as its argument not {type(uvm_type)}"
        )
        return uvm_type in self.fd.classes.values()

    @property
    def debug_level(self):
        """
        * uvm_factory().debug_level = 0 : overrides
        * uvm_factory().debug_level = 1 : user defined types + above
        * uvm_factory().debug_level = 2 : uvm_* types + above
        """
        return self.__debug_level

    @debug_level.setter
    def debug_level(self, debug_level):
        """
        * uvm_factory().debug_level = 0 : overrides
        * uvm_factory().debug_level = 1 : user defined types + above
        * uvm_factory().debug_level = 2 : uvm_* types + above
        """
        assert 0 <= debug_level <= 2, "uvm_factory().all_type must be 0, 1, or 2"
        self.__debug_level = debug_level

    def __str__(self):
        """
        Returns the Pythonic string
        Set uvm_factory().debug_level to a value to control the string.
        The default is 1

        uvm_factory().debug_level = 0 : overrides
        uvm_factory().debug_level = 1 : user defined types + above
        uvm_factory().debug_level = 2 : uvm_* types + above

        :return: String containing factory data
        """
        factory_str = "--- overrides "
        if self.debug_level != 0:
            factory_str += "+ user defined types "
        if self.debug_level == 2:
            factory_str += "+ uvm_* types "
        factory_str += "---\n\n"

        if len(self.fd.overrides) > 0:
            factory_str += "Overrides:\n"
            for inst in self.fd.overrides:
                # Override keys can be arbitrary strings (name-based overrides
                # of an unregistered original), which have no __name__.
                inst_name = getattr(inst, "__name__", str(inst))
                factory_str += f"{inst_name:25}" + ": " + str(self.fd.overrides[inst])
                factory_str += "\n"
        # Need to add 1 and 2
        user_list = [
            self.fd.classes[cls].__name__
            for cls in self.fd.classes
            if not fnmatch.fnmatch(self.fd.classes[cls].__name__, "uvm_*")
        ]
        uvm_list = [
            self.fd.classes[cls].__name__
            for cls in self.fd.classes
            if fnmatch.fnmatch(self.fd.classes[cls].__name__, "uvm_*")
        ]
        if self.debug_level > 0:
            factory_str += "\n" + "-" * 25 + "\nUser Defined Types:\n"
            factory_str += "\n".join(user_list)

        if self.debug_level == 2:
            factory_str += "\n" + "-" * 25 + "\nUVM Types:\n"
            factory_str += "\n".join(uvm_list)

        return factory_str

    # 8.3.1.7.5
    def print(self, debug_level=1):
        """
        :param debug_level:
            * ``debug_level`` = 0 : overrides
            * ``debug_level`` = 1 : user defined types + above ( default)
            * ``debug_level`` = 2 : uvm_* types + above
        :return: None

        Prints the factory data using debug_level to
        control the amount of output. The uvm_factory().debug_level
        variable can control this for __str__()
        """
        saved_debug_level = self.debug_level  # Avoiding a side effect
        self.debug_level = debug_level
        print(self)
        self.debug_level = saved_debug_level


# 8.3.1.8 Usage
# All the elements of usage have been implemented in pyuvm
# The biggest difference is that all uvm_void classes get registered
# with the factory automatically.

# 8.3.2
# Not implemented.  There is no need for a uvm_object_wrapper
# in Python. The user will never notice
# the difference
