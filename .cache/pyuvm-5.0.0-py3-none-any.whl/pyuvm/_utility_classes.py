import fnmatch
import inspect
import logging
import re
from collections import OrderedDict
from dataclasses import dataclass
from functools import lru_cache

import cocotb.queue
from cocotb.queue import QueueEmpty
from cocotb.triggers import Event, NullTrigger

FIFO_DEBUG = 5
PYUVM_DEBUG = 4
logging.addLevelName(FIFO_DEBUG, "FIFO_DEBUG")
logging.addLevelName(PYUVM_DEBUG, "PYUVM_DEBUG")


if int(cocotb.__version__.split(".")[0]) >= 2:
    from cocotb.task import current_task
else:

    def current_task():
        return cocotb.scheduler._current_task


def count_bits(nn):
    """
    Count the number of bits in a number

    :param nn: The number to count the bits in
    :return: The number of bits
    """
    # Convert the absolute value of n to binary and count the '1's
    return bin(abs(nn)).count("1")


class Singleton(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]

    @classmethod
    def clear_singletons(cls, keep):
        classes = list(cls._instances.keys())
        for del_cls in classes:
            if del_cls not in keep:
                del cls._instances[del_cls]


class Override:
    """
    This class stores an override and an optional path.
    It is intended to be stored in a dict with the original class
    as the key.
    """

    def __init__(self):
        self.type_override = None
        self.inst_overrides = OrderedDict()

    def add(self, override, path=None):
        if path is None:
            self.type_override = override
        else:
            self.inst_overrides[path] = override

    def find_inst_override(self, path):
        for inst in self.inst_overrides:
            if fnmatch.fnmatch(path, inst):
                return self.inst_overrides[inst]
        return None

    def __str__(self):
        """
        For printing out the overrides
        :return: str
        """
        if self.type_override is not None:
            to = "Type Override: " + f"{self.type_override.__name__}"
        else:
            to = "Type Override: None"
        ss = f"{to:25}" + " || "
        io = " | ".join(
            [
                (
                    f"{inst_path[:29] if len(inst_path) > 29 else inst_path}"
                    f" => {inst_override.__name__}"
                )
                for inst_path, inst_override in self.inst_overrides.items()
            ]
        )
        ss += f"Instance Overrides: {io}" if io else ""

        return ss


class FactoryData(metaclass=Singleton):
    def __init__(self):
        self.classes = {}
        self.clear_overrides()
        self.logger = logging.getLogger("Factory")

    def clear_overrides(self):
        self.overrides = {}

    def clear_classes(self):
        self.classes = {}

    # From 8.3.1.5
    def find_override(self, requested_type, inst_path=None, overridden_list=None):
        """
        :param requested_type: The type we're overriding
        :param inst_path: The inst_path we're using to override if any
        :param overridden_list: A list of previously found overrides
        :return: overriding_type

        Override searches are recursively applied, with instance
        overrides taking precedence over type overrides.
        If foo overrides bar, and xyz overrides foo, then a request for bar
        returns xyx.
        """

        # xyz -> foo -> bar
        #
        # So if find_override is f:
        #     f(xyz) -> f(foo) -> f(bar) <-- no override returns bar.
        # Recursive loops result ina n error in which case the
        # type returned is the one that formed the loop:
        # xyz -> foo -> bar -> xyz
        #
        # f(xyz) -> f(foo) -> f(bar) -> f(xyz) -- xyz is in
        # list of overrides so return bar
        # bar is returned with a printed error.
        #
        # We use the Override class which contains both the type override if
        # there is one or
        # a list of instance overrides in the order the were added.
        # If inst_path is None we return the type_override or its override
        # If inst_path is given, but we don't find a match we return
        # type_override if it exists

        # Keep track of what classes have been overridden
        #

        # Is there an override loop?
        # noinspection PyShadowingNames
        def check_override(override, overridden_list):
            if overridden_list is None:
                overridden_list = []
            if override in overridden_list:
                self.logger.error(
                    "%s already overridden: %s", requested_type, overridden_list
                )
                return requested_type
            else:
                overridden_list.append(requested_type)
                rec_override = self.find_override(override, inst_path, overridden_list)
                return rec_override

        # Save the type for a later check
        # Is this requested type even in the list of overrides?
        try:
            override = self.overrides[requested_type]
        except KeyError:
            return requested_type

        if inst_path is not None:
            for path in override.inst_overrides:
                if fnmatch.fnmatch(inst_path, path):
                    found_type = override.inst_overrides[path]
                    return check_override(found_type, overridden_list)

        # No inst requested or found, do we have a type override?
        if override.type_override is not None:
            return check_override(override.type_override, overridden_list)
        else:
            return requested_type


class FactoryMeta(type):
    """
    This is the metaclass that causes all uvm_void classes
    to register themselves
    """

    def __init__(cls, name, bases, cls_dict):
        FactoryData().classes[cls.__name__] = cls
        super().__init__(name, bases, cls_dict)


class uvm_void(metaclass=FactoryMeta):
    """
    5.2
    SystemVerilog Python uses this class to allow all
    uvm objects to be stored in a uvm_void variable through
    polymorphism.

    In pyuvm, we're using uvm_void() as a metaclass so
    that all UVM classes can be stored in a factory.
    """


class UVM_ROOT_Singleton(FactoryMeta):
    singleton = None

    def __call__(cls, *args, **kwargs):
        if cls.singleton is None:
            cls.singleton = super().__call__(*args, **kwargs)
        return cls.singleton

    @classmethod
    def clear_singletons(cls):
        cls.singleton = None
        pass


@dataclass
class Objection:
    """Details about a raised objection, to assist in diagnosing hangs/timeouts"""

    raiser_name: str
    description: str
    sourceline: str

    def __str__(self):
        return f'raised by {self.raiser_name}, description="{self.description}", raised at {self.sourceline}'


class ObjectionHandler(metaclass=Singleton):
    """
    This singleton accepts objections and then allows
    them to be removed. It returns True to run_phase_complete()
    when there are no objections left.
    """

    def __init__(self):
        self.__objections = {}  # Dict holds a list for each objecting UVM component
        self._objection_event = Event()
        # Count of raised-but-not-yet-dropped objections across all components.
        # The phase ends when this reaches zero (IEEE 1800.2 10.5 count-based
        # semantics), not merely when the last component's list empties.
        self._outstanding = 0
        # Edge-triggered: True once any objection is raised during the phase.
        # Used only to emit the "no objection raised" warning; it must NOT gate
        # whether we wait, otherwise a run_phase that raises and drops within a
        # single scheduler slot is treated as if it never objected.
        self.objection_raised = False
        self.run_phase_done_flag = None  # used in test suites
        self.printed_warning = False

    def __str__(self):
        """
        :return: String representation of all active objections
        Example::
            from pyuvm.utility_classes import ObjectionHandler
            print(str(ObjectionHandler()))
        """
        ss = "Active objections:"
        if not self.__objections:
            ss += " None\n"
            return ss
        ss += "\n"
        objlists = self.__objections.values()
        lines = [f" {objection}" for component in objlists for objection in component]
        ss += "\n".join(lines)
        return ss

    def clear(self):
        if self.__objections:
            logging.getLogger("uvm").warning("Clearing all objections\n%s", str(self))
            self.__objections = {}
        self._outstanding = 0
        self.objection_raised = False
        self._objection_event.clear()

    def get_objection_count(self):
        """:return: number of raised objections not yet dropped"""
        return self._outstanding

    def raise_objection(self, raiser, description, stacklevel=1):
        name = raiser.get_full_name()
        frame = inspect.stack()[stacklevel].frame
        sourceline = f"{frame.f_code.co_filename}:{frame.f_lineno}"
        objection = Objection(name, description, sourceline)
        self.__objections.setdefault(name, []).append(objection)
        self._outstanding += 1
        self.objection_raised = True
        self._objection_event.clear()

    def drop_objection(self, dropper, description):
        name = dropper.get_full_name()
        if not self.__objections.get(name):
            # A drop with no matching raise is a no-op; it must not crash
            # the run phase or corrupt the outstanding count.
            logging.getLogger("pyuvm").warning(
                "Dropped objection for '%s' with no matching raise", name
            )
            return
        self.__objections[name].pop()
        if not self.__objections[name]:
            del self.__objections[name]
        self._outstanding -= 1
        # The phase may end only when every raised objection has been dropped.
        if self._outstanding == 0:
            self._objection_event.set()

    async def run_phase_complete(self):
        # Allow the run_phase coros to get scheduled and raise objections:
        await NullTrigger()
        if not self.objection_raised:
            logging.getLogger("pyuvm").warning(
                "You did not call self.raise_objection() in any run_phase"
            )
            return
        # Wait for the outstanding objection count to reach zero. We always wait
        # on the event at least once (even if the count is already zero) so that
        # daemon run_phase coroutines get a scheduler turn to finish draining.
        # The loop re-checks the count to handle a raise that bumps it back up
        # between the count hitting zero and this coroutine resuming.
        while True:
            await self._objection_event.wait()
            if self._outstanding == 0:
                break


class UVMQueue(cocotb.queue.Queue):
    """
    The UVMQueue provides a peek function as well as the
    ability to break out of a blocking operation if
    the time_to_die predicate is true.  The time
    to die is set to the dropping of all run_phase objections
    by default.
    """

    def __str__(self):
        return str(self._queue)

    def _peek(self):
        return self._queue[0]

    async def peek(self):
        """Remove and return an item from the queue.
        If the queue is empty, wait until an item is available.
        """
        while self.empty():
            event = Event()
            self._getters.append((event, current_task()))
            await event.wait()
        return self.peek_nowait()

    def peek_nowait(self):
        """Remove and return an item from the queue.
        Return an item if one is immediately available, else raise
        :exc:`asyncio.QueueEmpty`.
        """
        if self.empty():
            raise QueueEmpty()
        item = self._peek()
        return item


@lru_cache(maxsize=128)
def _get_compiled_pattern(expr: str):
    if expr.startswith("/") and expr.endswith("/"):
        return re.compile(expr[1:-1])

    escape_pattern = re.escape(expr)
    escape_pattern = escape_pattern.replace(r"\*", ".*")
    escape_pattern = escape_pattern.replace(r"\+", ".+")
    escape_pattern = escape_pattern.replace(r"\?", ".")
    return re.compile(escape_pattern)


def uvm_is_match(expr: str, string: str) -> bool:
    pattern = _get_compiled_pattern(expr)
    return bool(pattern.fullmatch(string))
